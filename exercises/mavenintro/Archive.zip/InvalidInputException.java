package nl.ica.ddoa.dda.reverse;

public class InvalidInputException extends Exception {

}
